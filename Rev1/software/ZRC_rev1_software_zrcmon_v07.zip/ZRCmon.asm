;ported from Z80SBC64 monitor
;Remove the C0 command.  This monitor is loaded differently
;Add ability to load extended Intel Hex file
;Add saving and booting ROMWBW
;Reduce the complexity of the monitor to serve just ROMWBW
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ZRCMon, Copyright (C) 2020 Hui-chien Shen
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

SerData  	equ 081h        	; CPLD UART Tx/Rx register
SerStat  	equ 080h        	; CPLD UART status/control register

CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

bankReg	equ 01fh		; ZRC bank control register
; write only register
; power on value is 0x3F
; common area is at top 32K
; write 1xxx_xxxx to disable the 64-byte ROM in CPLD
	org 0b000h
	jp 0b400h		;after power on reset, CPLD ROM will jump to 0xB000

	org 0b400h		
	jp start
; variable area
testseed: ds 2		; RAM test seed value
addr3116	ds 2		; high address for Intel Hex format 4
RDsector	ds 1		; current RAM disk sector
RDtrack	ds 1		; current RAM disk track 
RDaddr	ds 2		; current RAM disk address 
sectoff	ds 2		; offset from a track & sector
blinkLED	ds 1		;0 turn off LED, 1 turns on LED
currbank	ds 1		; current RAM bank
fUpload	ds 1		;extended addressing flag
wbwloop	ds 1		;ROMWBW inner loop
	ds 1		;ROMWBW outer loop
wbwbank	ds 1		;ROMWBW bank value
	ds 1		;ROMWBW storage sector number
;Initialization and sign-on message
start:
	ld sp,0b400h	; initialize stack just below program start
	ld a,80h		; page away CPLD ROM
	out (bankReg),a	;
	xor a
	ld (currbank),a	;store 0 as current bank number
	ld (sectoff),a	;initialize (clear) sector offset
	ld (sectoff+1),a
    	LD HL,signon$
        	CALL strout

	ld hl,251		; initialize RAM test seed value
	ld (testseed),hl	; save it
clrRx:  
        	IN A,(SerStat)	; read on-chip UART receive status
        	AND 1				; data available?
        	jr z,CMD
        	IN A,(SerData)	; read clear the input buffer
	jr clrRx

;Main command loop
CMD:  	LD HL, PROMPT$
        	CALL strout
CMDLP1:
        	CALL cinq
	cp ':'		; Is this Intel load file?
	jr z,initload
	cp 0ah		; ignore line feed
	jr z,CMDLP1
	cp 0dh		; carriage return get a new prompt
	jr z,CMD
	CALL cout		; echo character
        	AND 5Fh
	cp 'H'		; help command
	jp z,HELP
        	CP A,'D'
        	JP Z,MEMDMP
        	CP A,'E'
        	JP Z,EDMEM
	cp a,'I'		; read data from specified I/O port in page 0
	jp z,INPORT
	cp a,'O'		; write data to specified I/O port in page 0
	jp z,OUTPORT
	cp a,'L'		; list memory as Intel Hex format
	jp z,LISTHEX
        	CP A,'G'
        	JP Z,go
	cp a,'R'		; read a CF sector
	jp z,READRD
	cp a,'Z'		; fill memory with zeros
	jp z,fillZ
	cp a,'F'		; fill memory with ff
	jp z,fillF
	cp a,'C'		; Copy to CF	
	jp z,COPYCF
	cp a,'T'		; testing RAM 
	jp z,TESTRAM
	cp 'B'		; boot CPM
	jp z,BootCPM
	cp 'X'		; clear CF directory
	jp z,format

what:
        	LD HL, what$
        	CALL strout
        	jp CMD
abort:
	ld hl,abort$	; print command not executed
	call strout
	jp CMD
; initialize for file load operation
initload:
	ld hl,0		; clear the high address in preparation for file load
	ld (addr3116),hl	; addr3116 modified with Intel Hex format 4 
	xor a		
	ld (fUpload),a	;assuming this is not a file in extended address format
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jp z,filesave
	cp 1		; end of file transfer?
	jr z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
; limit the memory size to 16 meg, so will ignore the highest byte of 32-bit address
; if upload flag, fUpload, is cleared (default), then bank 0 and bank 0x3F are for 0x0-0xFFFF
; if upload flag, fUpload, is not zero (with U command), then:
; bank 0 and bank 1 are for 0x0-0xFFFF
; bank 2 and bank 3 are for 0x10000-0x1FFFF
; bank 4 and bank 5 are for 0x20000-0x2FFFF
; bank 6 and bank 7 are for 0x30000-0x3FFFF
;   etc
; the formula is current bank = high byte x 2  
; if address is greater than 0x8000, it goes to current bank + 1
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jp nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'

	ld a,(addr3116)	;calculate the current bank value
	sla a		;shift left one bit
	ld (currbank),a	;currbank = addr3116 * 2 
	out (bankReg),a
	ld a,1
	ld (fUpload),a	;flag this file upload as extended addressing file
	ld a,'E'		; denote a successful Extended linear addr update
	jr filesav2
; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld a,'X'		; mark the end with 'X'
	call cout
	ld a,10			; carriage return and line feed
	call cout
	ld a,13
	call cout
	xor a
	out (bankReg),a	;point bank register to first page
	jp CMD
; the assumption is the data is good and will be saved to the destination memory
; if addr3116 and addr3116+1 are zero, then HL load normally
; if addr3116 and addr3116+1 are non zero, then HL lesser than 0x8000 loads to current bank
;  and HL greater than 0x8000 loads to current bank + 1
filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,(fUpload)	;decide how to save data based on upload flag
	or a
	jr z,filesavx	;upload flag is zero
	ld a,h		;test the high byte of HL register
	or a
	jp p,filesavx	;HL lesser than 0x8000
	and 7fh		;mask off the most significant bit of HL
	ld h,a
	ld a,(currbank)	;increment the bank for HL 0x8000 or greater
	inc a
	out (bankReg),a	
	call filesav
	ld a,(currbank)	;restore the current bank value to bank register
	out (bankReg),a
	jp calchksum
filesav:
	call GETHEXQ	; get a byte
	ld (hl),a		; data to destination
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc hl		;Z80SBC 
	dec d
	jr nz,filesav
	ret

filesavx:
	call GETHEXQ	; get a byte
	ld (hl),a		; save data to destination
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc hl		;
	dec d
	jr nz,filesavx
calchksum:
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'

	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jr nz,flushln
	jp fileload
; format CF drives directories unless it is RAM disk
; drive A directory is track 1, sectors 0-0x1F
; drive B directory is track 0x40, sectors 0-0x1F
; drive C directory is track 0x80, sectors 0-0x1F
; drive D directory is track 0xC0, sectors 0-0x1F
format:
	ld hl,clrdir$	; command message
	call strout
	call cin
	cp 'A'
	jr z,formatA	; fill track 1 sectors 0-0x1F with 0xE5
;	cp 'B'
;	jr z,formatB	; fill track 0x40 sectors 0-0x1F with 0xE5
;	cp 'C'
;	jr z,formatC	; fill track 0x80 sectors 0-0x1F with 0xE5
;	cp 'D'
;	jr z,formatD	; fill track 0xC0 sectors 0-0x1F with 0xE5
	jp abort		; abort command if not in the list of options
formatA:
	ld de,100h	; start with track 1 sector 0
;	jr doformat
;formatB:
;	ld de,4000h	; start with track 0x40 sector 0
;	jr doformat
;formatC:
;	ld de,8000h	; start with track 0x80 sector 0
;	jr doformat
;formatD:
;	ld de,0c000h	; start with track 0xC0 sector 0
doformat:
	ld hl,confirm$	; confirm command execution
	call strout
	call tstCRLF
	jp nz,abort	; abort command if not CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; MSB track is 0
	ld a,d		; reg D contains the track info
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
	ld hl,0e5e5h	; value for empty directories
wrCFf:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,e		; write CPM sector
	cp 20h		; format sector 0-0x1F
	jp z,wrCFdonef	; done formatting
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	; check data request bit set before write CF data

	ld b,0h		; sector has 256 16-bit data
loopf:
	out (c),h		;z80 writes 2 bytes to CF
	out (c),h	
	inc b
	jp nz,loopf
	call readbsy	;wait on CF status busy bit

	inc e		; write next sector
	jp wrCFf
wrCFdonef:
	jp CMD

chkdrq:
	in a,(CFstat)	; check data request bit set before write CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,chkdrq
	ret
INPORT:
; read data from specified I/O port in page 0
; command format is "I port#"
; 
	ld hl,inport$	; print command 'I' prompt
	call strout
	call GETHEX	; get port # into reg A
	push bc		; save register
	ld c,a		; load port # in reg C
	in b,(c)		; get data from port # into reg B
	ld hl,invalue$
	call strout
	ld a,b
	call HEXOUT
	pop bc		; restore reg
	jp CMD
OUTPORT:
; write data to specified I/O port in page 0
; command format is "O value port#"
	ld hl,outport$	; print command 'O' prompt
	call strout
	call GETHEX	; get value to be output
	push bc		; save register

	ld b,a		; load value in reg B
	ld hl,outport2$	; print additional prompt for command 'O'
	call strout
	call GETHEX	; get port number into reg A
	ld c,a
	out (c),b		; output data in regB to port in reg C
	pop bc
	jp CMD
LISTHEX:
; list memory as Intel Hex format
; the purpose of command is to save memory as Intel Hex format to console
	ld hl,listhex$	; print command 'L' prompt
	call strout
	call ADRIN	; get address word into reg DE
	push de		; save for later use
	ld hl,listhex1$	; print second part of 'L' command prompt
	call strout
	call ADRIN	; get end address into reg DE
listhex1:
	ld hl,CRLF$	; put out a CR, LF	
	call strout
	ld c,10h		; each line contains 16 bytes
	ld b,c		; reg B is the running checksum
	ld a,':'		; start of Intel Hex record
	call cout
	ld a,c		; byte count
	call HEXOUT
	pop hl		; start address in HL
	call ADROUT	; output start address
	ld a,b		; get the checksum
	add a,h		; accumulate checksum
	add a,l		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	xor a		
	call HEXOUT	; record type is 00 (data)
listhex2:
	ld a,(hl)		; get memory pointed by hl
	call HEXOUT	; output the memory value in hex
	ld a,(hl)		; get memory again
	add a,b		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	inc hl
	dec c
	jp nz,listhex2
	ld a,b		; get the checksum
	neg a
	call HEXOUT	; output the checksum
; output 16 memory location, check if reached the end address (saved in reg DE)
; unsign compare: if reg A < reg N, C flag set, if reg A > reg N, C flag clear
	push hl		; save current address pointer
	ld a,h		; get MSB of current address
	cp d		; reg DE contain the end address
	jp nc,hexend	; if greater, output end-of-file record
	jp c,listhex1	; if less, output more record
; if equal, compare the LSB value of the current address pointer
	ld a,l		; now compare the LSB of current address
	cp e
	jp c,listhex1	; if less, output another line of Intel Hex
hexend:
; end-of-record is :00000001FF
	ld hl,CRLF$
	call strout
	ld a,':'		; start of Intel Hex record
	call cout
	xor a
	call HEXOUT	; output "00"
	xor a
	call HEXOUT	; output "00"
	xor a
	call HEXOUT	; output "00"
	ld a,1
	call HEXOUT	; output "01"
	ld a,0ffh
	call HEXOUT	; output "FF"

	pop hl		; clear up the stack
	jp CMD

; print help message
HELP:
	ld hl,HELP$	; print help message
	call strout
help1:
	call readbsy	;;8 wait until busy flag is cleared
	ld a,0e0h		;;8 set up LBA mode
	out (CF2427),a	;;8
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call readbsy	;;8 wait until busy flag is cleared
	jp CMD
; boot CPM
; copy program from LA9-LA26 (9K) to 0xDC00
; jump to 0xF200 after copy is completed.
BootCPM:
	ld hl,bootcpm$	; print command message
	call strout
	call cin		; get input
;	cp '1'		; '1' is user apps
;	jp z,bootApps
;	cp '2'		; '2' is cpm2.2
;	jp z,boot22
;	cp '3'		; '3' is cpm3, not implemented
;	jp z,boot3
	cp '4'		; ROMWBW
;	jp z,bootwbw
;	cp '5'
	jp z,bootwbwfile
	jp what
bootwbwfile:
; load 512K ROMWBW image stored in first file of first slice of CF disk
; it starts from track 01, sector 20 and ends at track 05 sector 19
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	call readbsy
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call readbsy	;;8 wait until busy flag is cleared

	ld ix,wbwloop	;ix is inner loop, ix+1 is outer loop2
	ld iy,wbwbank	;iy is memory bank iy+1 is sector
	ld a,4
	ld (ix+1),a	;outer loop is 4
	xor a
	ld (iy),a		;bank reg starts from 0
	ld a,01h		;WBW is stored in sectors 01, 02, 03, 04, and some in 05
	ld (iy+1),a

outerloopf:
	ld de,2060h	;start with sector 20 to sector 5f
	ld a,4
	ld (ix),a		;inner loop is 4
innerloopf:
	ld a,(iy)		;get memory bank number
	out (bankReg),a
	inc (iy)
	ld hl,0		;memory location from 0-7FFF
	ld a,(iy+1)	;set track number
	call rdCF
	ld a,(ix)		;check inner loop count
	cp 4
	jr nz,inner2f
	ld de,60a0h	;set start/end sectors to 60/9f
inner2f:
	cp 3
	jr nz,inner1f
	ld de,0a0e0h	;set start/end sectors to a0/df
inner1f:
	cp 2
	jr nz,inner1zf
	ld de,0e000h	;set start/end sectors to e0/ff

inner1zf:
;special case for innerloop count of 1
;HL points to 0x4000
;do not change bankReg
;increment track
	cp 1
	jp nz,inner0f
	ld de,0020h	;set start/end sectors to 00/20 of next track
	inc (iy+1)	;increment the track number
	ld hl,4000h
	ld a,(iy+1)	;get track number
	call rdCF

inner0f:
	dec (ix)
	jp nz,innerloopf
;	inc (iy+1)	;increment track number
;do not increase track number, it is already done in inner1zf
	dec (ix+1)
	jr nz,outerloopf

	xor a
	out (bankReg),a	;set memory bank to lowest 32K RAM
	jp 0

;bootwbw:
; load 512K ROMWBW image stored in tracks 3E, 3F, 40, 41 into lowest 512K RAM and execute
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a

;	ld ix,wbwloop	;ix is inner loop, ix+1 is outer loop2
;	ld iy,wbwbank	;iy is memory bank iy+1 is sector
;	ld a,4
;	ld (ix+1),a	;outer loop is 4
;	xor a
;	ld (iy),a	;bank reg starts from 0
;	ld a,3eh		;WBW is stored in sectors 3E, 3F, 40, 41
;	ld (iy+1),a

;outerloop:
;	ld de,0040h	;start with sector 0 to sector 3f
;	ld a,4
;	ld (ix),a		;inner loop is 4
;innerloop:
;	ld a,(iy)		;get memory bank number
;	out (bankReg),a
;	inc (iy)
;	ld hl,0		;memory location from 0-7FFF
;	ld a,(iy+1)	;set track number
;	call rdCF
;	ld a,(ix)		;check inner loop count
;	cp 4
;	jr nz,inner2
;	ld de,4080h	;set start/end sectors to 40/7f
;inner2:
;	cp 3
;	jr nz,inner1
;	ld de,80c0h	;set start/end sectors to 80/bf
;inner1:
;	cp 2
;	jr nz,inner0
;	ld de,0c000h	;set start/end sectors to c0/00

;inner0:
;	dec (ix)
;	jp nz,innerloop
;	inc (iy+1)	;increment track number
;	dec (ix+1)
;	jr nz,outerloop

;	xor a
;	out (bankReg),a	;set memory bank to lowest 32K RAM
;	jp 0

rdCF:
; reads specified sectors into specified starting address in memory and execute
; hl specifies the starting address in memory
; de specifies the starting and end sectors
; a specifies the track value
; bankReg specifies the 32K memory bank
	out (CF815),a	; track specified by reg A
	xor a
	out (CF1623),a
	ld c,CFdata	; reg C points to CF data reg
readCF:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp e		; reg E is the end sector value
	ret z		; done copying, 
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readCF

;boot3:
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a
;
;	ld hl,1100h	;CPM3LDR starts from 0x1100
;	ld de,0110h	;read from LA 1 to LA 0f
;	xor a		;track 0
;	call rdCF
;	jp 1100h		;CPM3 starting address

;boot22:
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a
;	xor a		; clear reg A
;	out (CF1623),a	; track 0
;	out (CF815),a
;	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
;	ld c,CFdata	; reg C points to CF data reg
;	ld d,80h		; read from LA 0x80 to LA 0x92
;readCPM1:
;	ld a,1		; read 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; read CPM sector
;	cp 92h		; between LA80h and LA91h
;	jp z,goCPM	; done copying, execute CPM
;	out (CF07),a	; 
;	ld a,20h		; read sector command
;	out (CFstat),a	; issue the read sector command
;	call chkdrq	; check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	inir		;z80 read 256 bytes
;	inir		;z80 read 256 bytes

;	inc d		; read next sector
;	jp readCPM1
;goCPM:
;	jp 0f200h		; BIOS starting address of CP/M

;bootApps:
;restore user application from CF disk to 0x0-0xAFFF
;jump to 0 when done
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF

;	xor a		; clear reg A
;	out (CF1623),a	; track 0
;	out (CF815),a
;	ld hl,0		; user apps starts from 0x0 to 0xAFFF
;	ld c,CFdata	; reg C points to CF data reg
;	ld d,11h		; read from LA 0x11 to LA 0x70
;readApps:
;	ld a,1		; read 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; read CPM sector
;	cp 71h		; between LA11h and LA70h
;	jp z,goApp	; done copying, execute CPM
;	out (CF07),a	; 
;	ld a,20h		; read sector command
;	out (CFstat),a	; issue the read sector command
;	call chkdrq	; check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	inir		;z80 read 256 bytes
;	inir		;z80 read 256 bytes
;
;	inc d		; read next sector
;	jp readApps
;goApp:
;	jp 0		; User apps starts from 0x0

fillZ:
	ld hl,fill0$	; print fill memory with 0 message
	call strout
	ld b,0		; fill memory with 0
	jp dofill
fillF:
	ld hl,fillf$	; print fill memory with F message
	call strout
	ld b,0ffh		; fill memory with ff
dofill:
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld hl,PROGEND	; start from end of this program
	ld a,0ffh		; end address in reg A
filla:
	ld (hl),b		; write memory location
	inc hl
	cp h		; reached 0xFF00?
	jp nz,filla	; continue til done
	cp l		; reached 0xFFFF?
	jp nz,filla
	ld hl,0b000h	; fill value from 0xB000 down to 0x0000
fillb:
	dec hl
	ld (hl),b		; write memory location with desired value
	ld a,h		; do until h=l=0
	or l
	jp nz,fillb
	jp CMD

; Read CF disk
; data buffer is at 0x1000
; previous data is at 0x2000 for comparison to current data
READRD:
	ld hl,read$	; put out read command message
	call strout
	ld hl,track$	; enter track in hex value
	call strout
	call GETHEX	; get a byte of hex value as track
	ld (RDtrack),a	; save it 
	ld hl,sector$	; enter sector in hex value
	call strout
	call GETHEX	; get a byte of hex value as sector
	ld (RDsector),a	; save it
READRD1:
	ld hl,1000h	; copy previous block to 2000h
	ld de,2000h
	ld bc,200h	; copy 512 bytes
	ldir		; block copy

	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,0		; read first sector
	out (CF1623),a	; high byte of track is always 0
	ld a,(RDsector)	;Z80SBC get sector value
	out (CF07),a	; write sector
	ld a,(RDtrack)
	out (CF815),a
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	; check data request bit set before write CF data
	ld hl,1000h	; store CF data starting from 1000h
	ld c,CFdata	; reg C points to CF data reg
	ld b,0h		; sector has 256 16-bit data
	inir		;Z80SBC
	inir

dumpdata:
	ld d,32		; 32 lines of data
	ld hl,1000h	; display 512 bytes of data
dmpdata1:
	push hl		; save hl
	ld hl,CRLF$	; add a CRLF per line
	call strout
	pop hl		; hl is the next address to display
	call DMP16TS	; display 16 bytes per line
	dec d
	jp nz,dmpdata1

	ld hl,1000h	; compare with data block in 2000h
	ld bc,200h
	ld de,2000h
blkcmp:
	ld a,(de)		; get a byte from block in 2000h
	inc de
	cpi		; compare with corresponding data in 1000h
	jp po,blkcmp1	; exit at end of block compare
	jp z,blkcmp	; exit if data not compare
	ld hl,notsame$	; send out message that data not same as previous read
	call strout
	jp chkRDmore
blkcmp1:	
	ld hl,issame$	; send out message that data read is same as before
	call strout

chkRDmore:
	ld hl,0		;clear sector offset value
	ld (sectoff),hl
	ld hl,RDmore$	; carriage return for next sector of data
	call strout
	call tstCRLF	; look for CRLF
	jp nz,CMD		; 
	ld hl,(RDsector)	; load track & sector as 16-bit value
	inc hl		; increment by 1
	ld (RDsector),hl	; save updated values
	ld hl,track$	; print track & sector value
	call strout
	ld a,(RDtrack)
	call HEXOUT
	ld hl,sector$
	call strout
	ld a,(RDsector)
	call HEXOUT
	jp READRD1

readbsy:
; spin on CF status busy bit
	in a,(CFstat)	; read CF status 
	and 80h		; mask off all except busy bit
	jr nz,readbsy
	ret

; Write CF
;  allowable parameters are '1' for memory from 0x0 to 0xAFFF,
;   '2' for CPM2.2, '3' for CPM3, '4' for ROMWBW
; Set page I/O to 0, afterward set it back to 0FEh
COPYCF:
	ld hl,copycf$	; print copy message
	call strout
	call cin		; get write parameters
	cp '0'
	jp z,bootZRCMon	;boot ZRC Monitor
;	cp '1'
;	jp z,autoROMWBW	;enable auto boot of ROMWBW

;	jp z,cpApps
;	cp '2'
;	jp z,CopyCPM2
;	cp '3'
;	jp z,CopyCPM3
;	cp '4'
;	jp z,CopyWBW
	jp what		; error, abort command
	jp CMD
; test for CR or LF.  Echo back. return 0
tstCRLF:
	call cin		; get a character					
	cp 0dh		; if carriage return, output LF
	jp z,tstCRLF1
	cp 0ah		; if line feed, output CR 
	jp z,tstCRLF2
	ret
tstCRLF1:
	ld a,0ah		; put out a LF
	call cout
	xor a		; set Z flag
	ret
tstCRLF2:
	ld a,0dh		; put out a CR
	call cout
	xor a		; set Z flag
	ret

bootZRCMon:
;copy ZRC Monitor in track 0, sector F8 to FD
;modify the CFboot program in master boot sector (track 0, sector 1) to
;  load the ZRC Monitor
	ld hl,confirm$	; carriage return to execute the program
	call strout
	call tstCRLF
	jp nz,CMD		; abort command if not CR or LF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		;set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		;set feature command
	out (CFstat),a	
	call readbsy	;wait until busy flag is cleared
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	ld d,0f8h		;monitor is stored in sectors F8 to FD
	ld hl,0b400h	;points to beginning of the monitor
	ld c,CFdata
wmoresect:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
	cp 0feh		; read sectors 0xF8-0xFD
	jp z,bootMon	; modify the master boot sector
	out (CF07),a	; read the sector pointed by reg D		

	ld a,30h		; write sector command
	out (CFstat),a	; issue the read sector command
	call readdrq
	ld b,0h		; sector has 512 8-bit data
	otir
	otir
	call readbsy	;wait for write to finish
	inc d
	jp wmoresect
bootMon:
; modify the boot sector so it will boot ZRC Monitor after reset
;this is the program that copies the CFbootloader into CF disk at master boot record
;read the master boot record to a buffer area (0xb100-0xb2ff)
;  write the CFbootloader so each byte is copied twice
;  write the modified 512 bytes back out to master boot record
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	out (CF07),a	;master boot block
	ld b,a
	inc a
	out (CFsectcnt),a	;read 1 sector
	ld hl,0b100h	;buffer for existing master boot block data
	ld c,CFdata	;point to CF data register
	ld a,20h		;read command
	out (CFstat),a
	call readdrq
	inir		;fill the buffer with existing master boot record data
	ld b,CFbootldrend-CFbootldr	;number of bytes to write to buffer
	ld hl,CFbootldr	;point to source
	ld de,0b100h	;point to destination
cpCFbootldr:
	ld a,(hl)		;get data from source
	ld (de),a		;write to destination twice
	inc de
	ld (de),a
	inc de
	inc hl
	dec b		
	jr nz,cpCFbootldr
	
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	out (CF07),a	;master boot block
	ld b,a
	inc a
	out (CFsectcnt),a	;write 1 sector
	ld hl,0b100h	;point to the updated buffer
;	ld c,CFdata	;point to CF data register
	ld a,30h		;write command
	out (CFstat),a
	call readdrq	;wait for DRQ to set
	otir		;write CFbootldr program to master boot record
	otir
	call readbsy	;wait for write to finish
	jp help1		;go back to monitor through help which set feature to 8-bit mode

readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq
	ret

;	org 0b000h
; this load program will be loaded from master boot sector to 0xb000 
; program must be relocatable (relative addressing)
CFbootldr:
	ld a,0e0h		;set up LBA mode
	out (CF2427),a	
	ld a,1		; set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		; set feature command
	out (CFstat),a	
readbsyb:
	in a,(CFstat)	; check bsy flag first
	and 80h		; bsy flag is at bit 7
	jr nz,readbsyb

	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a

	ld d,0f8h		; points to sector to read, last 8 sectors in track 0
	ld hl,0b400h	; store CF data starting from 0b400h
	ld c,CFdata	; reg C points to CF data reg
moresectb:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
	cp 0feh		; read sectors 0xF8-0xFD
	jp z,0b400h	; load completed, run program loaded at 0xB400

	out (CF07),a	; read the sector pointed by reg D		

	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
readdrqb:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,readdrqb

	ld b,0h		; sector has 512 8-bit data
	inir
	inir

	inc d
	jr moresectb
	nop
	nop
	nop
CFbootldrend:		;end of CFboot loader



; write CPM to CF
; write data from 0xDC00 to 0xFFFF to CF LA128-LA146 (9K)
;CopyCPM2:
;	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
;	ld de,8092h	; reg DE contains beginning sector and end sector values
;	call wrCF
;	jp CMD
;CopyCPM3:
;	ld hl,1100h	; CPMLDR starts from 0x1100
;	ld de,0110h	; reg DE contains beginning sector and end sector values
;	call wrCF
;	jp CMD
;CopyWBW:
; write 512K of memory image to CF track 0x3E, 0x3F, 0x40, 0x41
;	ld hl,confirm$	; carriage return to execute the program
;	call strout
;	call tstCRLF
;	jp nz,CMD		; abort command if not CR or LF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a

;	ld ix,wbwloop	;ix is inner loop, ix+1 is outer loop2
;	ld iy,wbwbank	;iy is memory bank iy+1 is sector
;	ld a,4
;	ld (ix+1),a	;outer loop is 4
;	xor a
;	ld (iy),a	;bank reg starts from 0
;	ld a,3eh		;WBW is stored in sectors 3E, 3F, 40, 41
;	ld (iy+1),a

;outerloopc:
;	ld de,0040h	;start with sector 0 to sector 3f
;	ld a,4
;	ld (ix),a	;inner loop is 4
;innerloopc:
;	ld a,(iy)	;get memory bank number
;	out (bankReg),a
;	inc (iy)
;	ld hl,0		;memory location from 0-7FFF
;	ld a,(iy+1)	;set track number
;	call wrCFwbw
;	ld a,(ix)	;check inner loop count
;	cp 4
;	jr nz,inner2c
;	ld de,4080h	;set start/end sectors to 40/7f
;inner2c:
;	cp 3
;	jr nz,inner1c
;	ld de,80c0h	;set start/end sectors to 80/bf
;inner1c:
;	cp 2
;	jr nz,inner0c
;	ld de,0c000h	;set start/end sectors to c0/ff
;inner0c:
;	dec (ix)
;	jp nz,innerloopc
;	inc (iy+1)	;increment track number
;	dec (ix+1)
;	jr nz,outerloopc

;	xor a		;restore bank register to first 32K
;	out (bankReg),a
;	jp CMD
	
;cpApps:
; copy the memory contents below 0xB000 to CF flash
;	ld hl,0		;start from 0x0
;	ld de,1170h	;sectors 11 to sector 70
;	call wrCF
;	jp CMD

;wrCF:
;	push hl		; save value
;	ld hl,confirm$	; carriage return to execute the program
;	call strout
;	pop hl
;	call tstCRLF
;	jp nz,CMD		; abort command if not CR or LF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a
;	xor a		;high track is 0
;	out (CF1623),a	; 
;	xor a		; clear reg A
;wrCFwbw:
;	out (CF815),a	;low track specified by reg A
;	ld c,CFdata	; reg C points to CF data reg
;wrCF1:
;	ld a,1		; write 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; write CPM sector
;	cp e		; reg E contains end sector value

;	ret z
;	out (CF07),a	; 
;	ld a,30h		; write sector command
;	out (CFstat),a	; issue the write sector command
;	call chkdrq	; check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	otir		;z80 write 256 bytes
;	otir		;z80 wrute 256 bytes

;	call readbsy	;wait until busy flag is cleared

;	inc d		; write next sector
;	jp wrCF1
	
TESTRAM:
; test memory from top of this program to 0xFFFE 
	ld hl,testram$	; print test ram message
	call strout
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld iy,(testseed)	; a prime number seed, another good prime number is 211
TRagain:
	ld hl,PROGEND	; start testing from the end of this program
	ld de,137		; increment by prime number
	xor a
	ld (currbank),a	;set current bank to 0
	out (bankReg),a
TRLOOP:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	inc hl
	ld (hl),b
	inc hl
	add iy,de		; add a prime number
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRLOOP	; continue until reaching 0xFFFE
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRLOOP
	ld hl,0b000h	; test memory from 0xAFFF down to 0x0000
TR1LOOP:
	push iy
	pop bc		; bounce off stack
	dec hl
	ld (hl),b		; write MSB
	dec hl
	ld (hl),c		; write LSB
	add iy,de		; add a prime number
	ld a,h		; check h=l=0
	or l
	jp nz,TR1LOOP
	ld hl,PROGEND	; verify starting from the end of this program
	ld iy,(testseed)	; starting seed value
TRVER:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jp nz,TRERROR
	inc hl
	ld a,(hl)		; get MSB
	cp b
	jp nz,TRERROR
	inc hl
	add iy,de		; next reference value
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRVER	; continue verifying til end of memory
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRVER
	ld hl,0b000h	; verify memory from 0xB000 down to 0x0000
TR1VER:
	push iy		; bounce off stack
	pop bc
	dec hl
	ld a,(hl)		; get MSB from memory
	cp b		; verify
	jp nz,TRERROR
	dec hl
	ld a,(hl)		; get LSB from memory
	cp c
	jp nz,TRERROR
	add iy,de
	ld a,h		; check h=l=0
	or l
	jp nz,TR1VER
TESTRAM8:
	call SPCOUT	; a space delimiter
	ld a,'O'		; put out 'OK' message
	call cout
	ld a,'K'
	call cout
	ld a,(currbank)	
	add a,30h
	call cout
	ld (testseed),iy	; save seed value

	IN A,(SerStat)	; read on-chip UART receive status
        	AND 1				;;Z data available?
        	jp nz,TESTRAM9	; no char, do another iteration of memory test
;test remaining 2Meg memory, 32K at a time
	ld a,(currbank)	;get the current bank number
	inc a
	cp 03fh		;topmost page is 0x3F
	jp z,TRagain	;start the RAM test from the beginning
	out (bankReg),a	;change 32K bank
	ld (currbank),a	;save the current bank value

	ld hl,7fffh	; start testing from top of 32K
TRLOOPn:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	dec hl
	ld (hl),b
	ld a,h		;check for hl reaching 0
	or l
	jp z,bTRVERn
	dec hl
	add iy,de		; add a prime number
	jp TRLOOPn
bTRVERn:
;verify 32K of memory
	ld iy,(testseed)	;start from seed value
	ld hl,7fffh
TRVERn:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jp nz,TRERROR
	dec hl
	ld a,(hl)		; get MSB
	cp b
	jp nz,TRERROR
	ld a,h		;check for hl reaching 0
	or l
	jp z,TESTRAM8
	dec hl
	add iy,de		; next reference value
	jp TRVERn

TESTRAM9
	xor a
	out (bankReg),a	;set RAM page back to 0
	jp clrRx		; clear the UART receive buffer and return to CMD
TRERROR:
	call SPCOUT	; a space char to separate the 'r' command
	ld a,'H'		; display content of HL reg
	call cout		; print the HL label
	ld a,'L'
	call cout
	call SPCOUT	
	call ADROUT	; output the content of HL 	
	jp CMD

;Get an address and jump to it
go:
	ld hl,go$		; print go command message
	call strout
        	CALL ADRIN
        	LD H,D
        	LD L,E
	push hl		; save go address
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	pop hl
	jp nz,abort
	jp (hl)		; jump to address if CRLF

;;;;;;;;;;;;;;;;;;;;;;;;;;; Utilities from Glitch Works ver 0.1 ;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;; Copyright (C) 2012 Jonathan Chapman ;;;;;;;;;;;;;;;;;;

;Edit memory from a starting address until X is
;pressed. Display mem loc, contents, and results
;of write.
EDMEM:  	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
ED1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	CALL SPCOUT
        	CALL DMPLOC
        	CALL SPCOUT
        	CALL GETHEX
        	JP C,CMD
        	LD (HL),A
        	CALL SPCOUT
        	CALL DMPLOC
        	INC HL
        	JP ED1

;Dump memory between two address locations
MEMDMP: 	CALL SPCOUT
        	CALL ADRIN
        	LD H,D
        	LD L,E
        	LD C,10h
        	CALL SPCOUT
        	CALL ADRIN
MD1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL DMP16
        	LD A,D
        	CP H
        	JP M,CMD
        	LD A,E
        	CP L
        	JP M,MD2
        	JP MD1
MD2:    	LD A,D
        	CP H
        	JP NZ,MD1
        	JP CMD

DMP16TS:
; dump memory pointed by HL, 
; print offset from the given track & sector values
;  as the address field
	push hl		; save reg
	ld a,'+'		;print offset symbol
	call cout
	ld hl,(sectoff)	;get offset from track&sector base
	call ADROUT	; output A23..A8
	push bc		;save reg
	ld bc,10h		;add 16 to offset
	add hl,bc
	pop bc
	ld (sectoff),hl	;save it
	pop hl		; restore reg
	jp DMP16D		; display the 16 data field

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMP16 -- Dump 16 consecutive memory locations
;
;pre: HL pair contains starting memory address
;post: memory from HL to HL + 16 printed
;post: HL incremented to HL + 16
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMP16:  	CALL ADROUT
DMP16D:			; 16 consecutive data
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	LD C,10h
	push hl		; save location for later use
DM1:    	CALL SPCOUT
        	CALL DMPLOC
        	INC HL		
        	DEC C
	jp nz,DM1

; display the ASCII equivalent of the hex values
	pop hl		; retrieve the saved location
	ld c,10h		; print 16 characters
	call SPCOUT	; insert two space
	call SPCOUT	; 
dm2:
	ld a,(hl)		; read the memory location
	cp ' '
	jp m,printdot	; if lesser than 0x20, print a dot
	cp 7fh
	jp m,printchar
printdot:
; for value lesser than 0x20 or 0x7f and greater, print '.'
	ld a,'.'
printchar:
; output printable character
	call cout
	inc hl
	dec c
	ret z
	jp dm2

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMPLOC -- Print a byte at HL to console
;
;pre: HL pair contains address of byte
;post: byte at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMPLOC: 	LD A,(HL)
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXOUT -- Output byte to console as hex
;
;pre: A register contains byte to be output
;post: byte is output to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXOUT: 	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	POP BC
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXASC -- Convert nybble to ASCII char
;
;pre: A register contains nybble
;post: A register contains ASCII char
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXASC: 	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADROUT -- Print an address to the console
;
;pre: HL pair contains address to print
;post: HL printed to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADROUT: 	LD A,H
        	CALL HEXOUT
        	LD A,L
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADRIN -- Get an address word from console
;
;pre: none
;post: DE contains address from console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADRIN:  	CALL GETHEX
        	LD D,A
        	CALL GETHEX
        	LD E,A
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GETHEX -- Get byte from console as hex
;
;pre: none
;post: A register contains byte from hex input
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GETHEX: 	PUSH DE
        	CALL cin
        	CP 'X'
        	JP Z,GE2
	cp 'x'		; exit with lower 'x'
	jp z,GE2
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cin
        	CALL ASCHEX
        	OR D
GE1:    	POP DE
        	RET
GE2:    	SCF
        	JP GE1

; get hex without echo back
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX: 	SUB 30h
        	CP 0Ah
        	RET M
        	AND 5Fh
        	SUB 07h
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GOBYT -- Push a two-byte instruction and RET
;         and jump to it
;
;pre: B register contains operand
;pre: C register contains opcode
;post: code executed, returns to caller
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GOBYT:  	LD HL,0000
        	ADD HL,SP
        	DEC HL
        	LD (HL),0C9h
        	DEC HL
        	LD (HL),B
        	DEC HL
        	LD (HL),C
        	JP (HL)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;SPCOUT -- Print a space to the console
;
;pre: none
;post: 0x20 printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
SPCOUT: 	LD A,' '
        	CALL cout
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;strout -- Print a null-terminated string
;
;pre: HL contains pointer to start of a null-
;     terminated string
;post: string at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
strout: 	LD A,(HL)
        	CP 00
        	RET Z
        	CALL cout
        	INC HL
        	JP strout
;;;;;;;;;;;;;;;;;;;;;;;;;;; Utilities by Glitch Works ver 0.1 ;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;; Copyright (C) 2012 Jonathan Chapman ;;;;;;;;;;;;;;;;;;

; input char into reg A
;  RxRdy is D[0] for ZRC
cin:
	in a,(SerStat)	;read status
	and 1		;data ready flag is in D[0]
	jr z,cin
	in a,(SerData)	; read data
	call cout		; echo back
	ret
; get char from console without echo
;  RxRdy is D[0] for ZRC
cinq:    
	in a,(SerStat)	;read status
	and 1		;data ready flag is in D[0]
	jr z,cinq
	in a,(SerData)	; read data
	ret

; output char in reg A
cout:
	push af
cout1:
	in a,(SerStat)	;get TxEmpty flag
	bit 1,a
	jr z,cout1
	pop af
	out (SerData),a
	ret
	
PROGEND:	equ 0c000h		; end of the program is above the stack

signon$:	db "ZRC Monitor v0.7 7/24/20", 13,10,0
;        	db "Format drives command",13,10,0 
PROMPT$:	db 13, 10, 10, ">", 0
what$:   	db 13, 10, "?", 0
CRLF$	db 13,10,0
confirm$	db " press Return to execute command",0
abort$	db 13,10,"command aborted",0
notdone$	db 13,10,"command not implemented",0
go$	db "o to address: 0x",0
track$	db " track:0x",0
sector$	db " sector:0x",0
read$	db "ead CF disk",0
RDmore$	db 10,13,"carriage return for next sector, any other key for command prompt",10,13,0
notsame$	db 10,13,"Data NOT same as previous read",10,13,0
issame$	db 10,13,"Data same as previous read",10,13,0
inport$	db "nput from port ",0
invalue$	db 10,13,"Value=",0
outport$	db "utput ",0
outport2$	db " to port ",0
listhex$	db "ist memory as Intel Hex, start address=",0
listhex1$	db " end address=",0
fillf$	db "ill memory with 0xFF",10,13,0
fill0$	db "ero memory",10,13,0
testram$	db "est memory",10,13,0
copycf$	db "opy to CF disk",10,13
;	db "0--boot,",10,13
;	db "1--User Apps, 0x0-0xAFFF",10,13
;	db "2--CP/M2.2:",10,13
;	db "3--CP/M3: ",10,13
;	db "4--ROMWBW: "
	db "0--boot ZRCMonitor",10,13
;	db "1--auto boot ROMWBW",10,13
	db 0
clrdir$	db " clear disk directories",10,13
	db "A -- drive A,",10,13
;	db "B -- drive B:",10,13
;	db "C -- drive C,",10,13
;	db "D -- drive D,",10,13	
;	db "E -- RAM drive: ",0
	db 0
bootcpm$	db "oot CP/M",10,13
;	db "1--User Apps,",10,13
;	db "2--CP/M2.2:",10,13
;	db "3--CP/M3: ",10,13
	db "4--ROMWBW: "
	db 0
;upload$	db " Extended addressing file upload",13,10,0
HELP$	db "elp",13,10
	db "G <addr> CR",13,10
	db "R <track> <sector>",13,10
	db "D <start addr> <end addr>",13,10
	db "I <port>",13,10
	db "O <value> <port>",13,10
	db "L <start addr> <end addr>",13,10
	db "Z CR",13,10
	db "F CR",13,10
	db "T CR",13,10
	db "E <addr>",13,10
	db "X <options> CR",13,10
	db "B <options> CR",13,10
	db "C <options> CR"
	db 0
	END


